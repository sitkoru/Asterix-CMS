<?php

class users_module extends default_module {

	public $title = 'Пользователь';

	//Таблица, где хранятся пользователи
	public $table = 'users';

	var $bad_passwords=array(
		'111111', '222222', '333333', '444444', '555555', '666666', '777777', '888888', '999999', '000000',
		'123456', '654321', 'qwerty', 'QWERTY', 'Qwerty', 'йцукен', 'ЙЦУКЕН', 'Йцукен',
		'1234567', '12345678', '123456789', '1234567890',
		'ПАРОЛЬ', 'пароль', 'gfhjkm', 'GFHJKM', 'зфыыцщкв', 'ЗФЫЫЦЩКВ', 'password', 'PASSWORD',
	);

	//Рейтинги пользователей
	var $ratings=array(
		'active' 	=> 'Активные пользователи',
//		'mobile' 	=> 'Мобильные пользователи',
		'grand' 	=> 'Старожилы',
		'new' 		=> 'Новички',
		'online' 	=> 'Сейчас на сайте',
		'all' 		=> 'Все наши пользователи',
	);

	//Спец.страницы
	public $pages=array(
		'profile',
	);

	public $auth_types=array(
		'login'=>true,
		'openid_yandex'=>true,
		'openid_google'=>true,
		'openid_mail'=>true,
		'openid_liveinternet'=>true,
	);

	//Шаблоны в модуле по умолчанию
	public $prepares=array(
		'modulepath' => array( 'function' => 'prepareModulePath', 'title' => 'Путь до корня модуля' ),
		'presentations' => array( 'function' => 'prepareMembersWithPresentations', 'title' => '' ),
		'regcount' => array( 'function' => 'prepareRegCount', 'title' => '' ),
		'delete' => array( 'function' => 'prepareDel', 'title' => '' ),
		'search' => array( 'function' => 'prepareSearch', 'title' => '' ),
	);

	//Установка структур модуля
	public function setStructure(){
		$this->structure=array(
			'rec'=>array(
				'title'=>'Пользователь',
				'fields'=>array(
					'date_logged'=>		array('type'=>'datetime','group'=>'system','title'=>'Дата последнего входа в систему'),

					'title'=>			array('type'=>'text','group'=>'main','title'=>'Имя, фамилия'),
					'login'=>			array('type'=>'text','group'=>'main','title'=>'Логин'),
					'password'=>		array('type'=>'password','group'=>'main','title'=>'Пароль','encrypt'=>'md5'),
					'avatar'=>			array('type'=>'image','group'=>'media','title'=>'Аватарка','resize_type'=>'outer','resize_width'=>400,'resize_height'=>400,'pre'=>array(
						'medium'=>			array('sid'=>'medium','resize_type'=>'outer','resize_width'=>100,'resize_height'=>100),
						'small'=>			array('sid'=>'small','resize_type'=>'outer','resize_width'=>62,'resize_height'=>62),
						'tiny'=>			array('sid'=>'tiny','resize_type'=>'outer','resize_width'=>38,'resize_height'=>38),
					)),
					'photo'=>			array('type'=>'image','group'=>'media','title'=>'Фотка','resize_type'=>'inner','resize_width'=>300,'resize_height'=>400),
					'preview'=>			array('type'=>'textarea','group'=>'main','title'=>'Коротко о себе'),
					'email'=>			array('type'=>'text','group'=>'main','title'=>'Адрес электронной почты'),

					'phone'=>			array('type'=>'text','group'=>'additional','title'=>'Контактный телефон'),
					'phone2'=>			array('type'=>'text','group'=>'additional','title'=>'Мобильный телефон'),
					'icq'=>				array('type'=>'text','group'=>'additional','title'=>'Аська'),
					'jabber'=>			array('type'=>'text','group'=>'additional','title'=>'Джабер'),
					'skype'=>			array('type'=>'text','group'=>'additional','title'=>'Скайп'),
					'twitter'=>			array('type'=>'text','group'=>'additional','title'=>'Твитер'),
					'fb'=>			array('type'=>'text','group'=>'additional','title'=>'Фэйсбук'),
					'vk'=>			array('type'=>'text','group'=>'additional','title'=>'Вконтакте'),
					'lj'=>			array('type'=>'text','group'=>'additional','title'=>'Живой журнал'),
					'web'=>				array('type'=>'text','group'=>'additional','title'=>'Сайт'),
					'blog'=>			array('type'=>'text','group'=>'additional','title'=>'Блог'),
					'openid'=>			array('type'=>'text','group'=>'system','title'=>'Open ID'),

					'company'=>			array('type'=>'text','group'=>'additional','title'=>'Компания'),
					'position'=>		array('type'=>'text','group'=>'additional','title'=>'Должность'),
					'city'=>			array('type'=>'text','group'=>'main','title'=>'Город'),
					'fax'=>				array('type'=>'text','group'=>'additional','title'=>'Факс'),

					'hotel'=>			array('type'=>'check','group'=>'additional','title'=>'Требуется ли проживание','default'=>false),
					'date_in'=>		array('type'=>'datetime','group'=>'additional','title'=>'Дата прибытия'),
					'date_out'=>		array('type'=>'datetime','group'=>'addititonal','title'=>'Дата отъезда'),
					'lunch'=>			array('type'=>'check','group'=>'additional','title'=>'Планируете ли заказывать бизнес-ланч (350р)','default'=>false),
					'coffe'=>			array('type'=>'check','group'=>'additional','title'=>'Планируете ли воспользоваться кофе-брейком (100р)','default'=>false),

					'show_phone'=>		array('type'=>'check','group'=>'additional','title'=>'Показывать номера телефонов', 'default'=>true),
					'show_company'=>	array('type'=>'check','group'=>'additional','title'=>'Показывать Компанию и должность', 'default'=>true),

					'moder'=>			array('type'=>'check','group'=>'main','title'=>'Пользователь является модератором сайта','default'=>false),
					'admin'=>			array('type'=>'check','group'=>'main','title'=>'Пользователь является администратором сайта','default'=>false),
					'active'=>			array('type'=>'check','group'=>'main','title'=>'Аккаунт активен','default'=>false),

					'subscribe'=>				array('type'=>'check','group'=>'main','title'=>'Подписка на рассылку новостей','default'=>true),

					'ip_protected'=>	array('type'=>'check','group'=>'main','title'=>'Включена защита по IP','default'=>false),
					'session_id'=>		array('type'=>'hidden','group'=>'main','title'=>'session_id','default'=>md5(date("Y-m-d H:i:s"))),
					'online'=>			array('type'=>'check','group'=>'main','title'=>'Пользователь сейчас на сате','default'=>false),

					'votes'=>			array('type'=>'votes','group'=>'additional','title'=>'Голосование за запись','default'=>false)
				),
				'type'=>'simple',
				'dep_path'=>false,
				'dep_param'=>false
			),
		);
	}

	//Установка интерфейсов модуля
	public function setInterfaces(){

		$this->interfaces=array(
			'login'=>array(
				'title'=>'Авторизация на сайте',		//Название интерфейса
				'structure_sid'=>'rec',					//Используемая структура текущего модуля
				'fields'=>array(
					'login'=>array(),
					'password'=>array(),
				),										//Поля, доступные в интерфейсе
				'ajax'=>true,
				'protection'=>false,					//Защита формы
				'auth'=>false,							//Требуется ли авторизация для работы с интерфейсом
				'values'=>false,						//Использовать ли уже имеющуюся запись
				'control'=>'authUser',					//Функция, отвечающая за обработку интерфейса после отправки
			),
			'registration'=>array(
				'title'=>'Регистрация на сайте',
				'structure_sid'=>'rec',
				'fields'=>array(
					'login'=>array(),
					'password'=>array(),
					'title'=>array(),
					'email'=>array(),
					'avatar'=>array('sid'=>'avatar', 'type'=>'image', 'title'=>'Выберите аватарку', 'template'=>'../mobi/fieldset_avatar.tpl'),
				),
				'ajax'=>true,
				'protection'=>'captcha',
				'auth'=>false,
				'use_record'=>false,
				'control'=>'registerUser',
			),
			'recover'=>array(
				'title'=>'Восстановление пароля',
				'structure_sid'=>'rec',
				'fields'=>array(
					'email'=>array(),
				),
				'ajax'=>true,
				'protection'=>false,
				'auth'=>false,
				'use_record'=>false,
				'control'=>'recoverPassword',
			),

			'profile' => array(

				'title' => 'Регистрационная анкета',
				'structure_sid' => 'rec',
				'fields' => array(

					'title' => array(),
					'company' => array( 'help' => 'Укажите компанию' ),
					'position' => array( 'help' => 'Укажите должность' ),
					'city' => array( 'help' => 'Укажите город', 'class' => 'general' ),

					'phone' => array( 'help' => 'Укажите номер телефона' ),
					'email' => array( 'help' => 'Укажите адрес электронной почты' ),

					'avatar' => array( 'class' => 'avatar' ),
/*
					'phone2' => array( 'class' => 'left' ),
					'fax' => array( 'class' => 'right' ),
					'web' => array( 'class' => 'left' ),
					'twitter' => array( 'class' => 'right' ),
					'fb' => array( 'class' => 'left' ),
					'vk' => array( 'class' => 'right' ),
					'lj' => array( 'class' => 'left' ),
					'blog' => array( 'class' => 'right' ),
*/
					'hotel' => array( 'class' => 'break' ),
					'date_in' => array( 'class' => 'left calendar', 'title' => 'Когда приезжаете?' ),
					'date_out' => array( 'class' => 'right calendar', 'title' => 'Когда выезжаете?' ),
//					'lunch' => array( 'class' => 'break' ),
//					'coffe' => array(),

					'preview' => array( 'class' => 'about break' )
				),
				'ajax'=>false,
				'protection'=>false,
				'auth'=>true,
				'use_record'=>true,
				'control'=>'updateProfile',
			),
			'password'=>array(
				'title'=>'Смена пароля',
				'structure_sid'=>'rec',
				'fields'=>array(
					'old'=>array('sid'=>'old','type'=>'password','group'=>'main','title'=>'Старый пароль'),
					'password'=>array('sid'=>'password','type'=>'password','group'=>'main','title'=>'Новый пароль'),
				),
				'ajax'=>true,
				'protection'=>false,
				'auth'=>true,
				'use_record'=>false,
				'control'=>'changePassword',
			),
			'block'=>array(
				'title'=>'Блокировка пользователя',
				'structure_sid'=>'rec',
				'fields'=>array(
					'id'=>array(),
					'active'=>array(),
				),
				'ajax'=>true,
				'protection'=>false,
				'auth'=>true,
				'use_record'=>true,
				'control'=>'updateActive',
			),
			'userblock'=>array(
				'title'=>'Блок пользователя',
				'structure_sid'=>'rec',
				'fields'=>array(
				),
				'ajax'=>true,
				'protection'=>false,
				'auth'=>true,
				'use_record'=>true,
				'control'=>'showMyBlock',
			),
			'usermail'=>array(
				'title'=>'Почта пользователя',
				'structure_sid'=>'rec',
				'fields'=>array(
				),
				'ajax'=>true,
				'protection'=>false,
				'auth'=>true,
				'use_record'=>true,
				'control'=>'showMyMail',
			),
			'subscribe'=>array(
				'title'=>'Подписка на смс-рассылки',
				'structure_sid'=>'rec',
				'fields'=>array(
				),
				'ajax'=>false,
				'protection'=>false,
				'auth'=>true,
				'use_record'=>true,
				'getfields'=>fieldsSubscribe,
				'control'=>'subscribe',
			),
		);
	}

	public function prepareModulePath(){
		return $this->info['url'];
	}

	public function authUser($values,$conditions=false){

		$this->model->user->authUser();

		if($this->model->user->info['id']){
			$result=array(
				'result'=>'redirect',
				'url'=>$_SERVER['HTTP_REFERER'],
				'close'=>true,
			);

		}else{
			$this->model->user->deleteCookie('auth');
			$result=array(
				'result'=>'message',
				'message'=>'Не получилось, попробуйте ещё',
				'close'=>false,
			);
		}

		$this->answerInterface($values['interface'],$result);
	}

	public function registerUser($values,$conditions=false){

		$errors=false;

		if( !strlen($values['login']) )$errors['login']='Вы забыли указать Логин';
		if( !strlen($values['password']) )$errors['password']='Вы забыли указать Пароль';
		if( strlen($values['password']) < 6 )$errors['password']='Пароль должен быть длиннее 6 символов';
		if( in_array($values['password'], $this->bad_passwords) )$errors['password']='Вы ввели очень простой пароль, придумайте что-нибудь посложнее';
		if( $values['password'] == $values['login'] )$errors['password']='Пароль не может совпадать с логином';
		if( $values['password'] == $values['title'] )$errors['password']='Пароль не может совпадать с именем на сайте';
		if( $values['password'] == $values['email'] )$errors['password']='Пароль не может совпадать с адресом электронной почты';
		if( $values['password'] !== $values['password_copy'] )$errors['password_copy']='Введённые пароли не совпадают';
		if( !strlen($values['title']) )$errors['title']='Вы забыли указать Имя на сайте';
		if( !strlen($values['email']) )$errors['email']='Вы забыли указать Адрес электронной почты';

		//Выводим ошибки
		if($errors){
			//Результирующий URL
			$result=array(
				'result'=>'error',
				'errors'=>$errors,
				'close'=>false,
			);
			//Ответ
			$this->answerInterface($values['interface'],$result);
		}

		if(!IsSet($values['login']))$values['login']=$values['email'];
		if(!IsSet($values['title']))$values['title']=$values['email'];

		//Проверка на уникальность логина и email`а
		$unique_login=$this->model->makeSql(
			array(
				'tables'=>array($this->getCurrentTable('rec')),
				'where'=>array(
					'and'=>array(
						'`login`="'.mysql_real_escape_string($values['login']).'"',
					),
				),
			),
			'getall'
		);$unique_login=!count($unique_login);

		//Проверка на уникальность логина и email`а
		$unique_email=$this->model->makeSql(
			array(
				'tables'=>array($this->getCurrentTable('rec')),
				'where'=>array(
					'and'=>array(
						'`email`="'.mysql_real_escape_string($values['email']).'"',
					),
				),
			),
			'getall'
		);$unique_email=!count($unique_email);

		//Если уникальный логин и email
		if($unique_login && $unique_email){
			if(!headers_sent())header("HTTP/1.0 200 Ok");
			//Доп.поля
			$values['sid']=$values['login'];
			$values['session_id']=session_id();
			$values['active']=1;
			$values['shw']=1;

			//Читаем размер рисунка
			$mime = GetImageSize($this->model->config['path']['www'].'/'.$values['avatar']);
			$size = filesize($this->model->config['path']['www'].'/'.$values['avatar']);

			$values['avatar']=array(
				'tmp_name'=>$this->model->config['path']['www'].'/'.$values['avatar'],
				'name'=>substr($values['avatar'], strrpos($values['avatar'],'/')+1 ),
				'type'=>$mime['mime'],
				'size'=>$size,
			);

			$_POST['login']=$values['login'];
			$_POST['password']=$values['password'];

			//Заводим запись
			$this->model->addRecord($this->info['sid'],'rec',$values);
			//Авторизуем на системном уровне
			$this->model->user->authUser();

			//Добавляем пустой фотоальбом "Неразобранное"
			$album_id=$this->model->modules['gallery']->getNextId('dir');
			$album=array(
				'id'=>$album_id,
				'sid'=>'album'.$album_id,
				'title'=>'Неразобранное',
				'author'=>$this->model->user->info['id'],
				'shw'=>1,
				'domain'=>'all',
			);
			$this->model->addRecord('gallery','dir',$album);

			//Пишем письмецо
			$head='Регистрация на сайте '.$this->model->extensions['domains']->domain['title'].'.';
			$body='Приветствуем, '.$rec['title'].'!

Кто-то, возможно Вы, зарегистрировались на сайте '.$this->model->extensions['domains']->domain['title'].'.
Если вы этого не делали - просто проигнорируйте это письмо.

Логин: '.$values['login'].'
Пароль: '.$values['password'].'

----
Желаем вам приятного дня,
Администраниця сайта '.$this->model->extensions['domains']->domain['title'].'.
			';

			$this->model->initEmail();
			$this->model->email->send($values['email'],$head,$body);

			//Результирующий URL
			$result=array(
				'result'=>'redirect',
				'url'=>'/site/welcome.html',
				'close'=>true,
			);
			//Ответ
			$this->answerInterface($values['interface'],$result);
		}

		if(!$unique_login){
			$errors['login']='Такой логин уже используется на сайте';
		}
		if(!$unique_email){
			$errors['email']='Такой email уже используется на сайте';
		}

		//Выводим ошибки
		if($errors){
			$_SESSION['messages']['feedback']=$errors;
			$_SESSION['messages']['feedback_memory']=$memory;
		}

		//Результирующий URL
		$result=array(
			'result'=>'error',
			'errors'=>$errors,
			'close'=>false,
		);
		//Ответ
		$this->answerInterface($values['interface'],$result);

	}

	//Восстановление пароля
	public function recoverPassword($values,$conditions=false){
		$rec=$this->model->makeSql(
			array(
				'tables'=>array($this->getCurrentTable('rec')),
				'fields'=>array('id','session_id','title','email'),
				'where'=>array('and'=>array('`email`="'.mysql_real_escape_string($values['email']).'"')),
			),
			'getrow'
		);

		//Если ползователь найден
		if(IsSet($rec['id'])){

			//URL для восстановления пароля
			$url='/recover.php?i='.md5($rec['session_id']);

			$head='Запрос о восстановлении пароля на сайте '.$this->model->extensions['domains']->domain['title'].'.';
			$body='Приветствуем, '.$rec['title'].'!

Кто-то, возможно Вы, запросил смену пароля на сайте '.$this->model->extensions['domains']->domain['title'].'.
Если вы этого не делали - просто проигнорируйте это письмо.

Для того, чтобы сменить пароль на сайте, пройдите по ссылке ниже:
http://'.$this->model->extensions['domains']->domain['host'].$url.'

----
Желаем вам приятного дня,
Администраниця сайта '.$this->model->extensions['domains']->domain['title'].'.
			';

			mail($rec['email'],$head,$body);

			//Возвращаем откуда пришёл
			$result=array(
				'result'=>'message',
				'message'=>'Вам отправлено письмо с информацией о восстановлении пароля.',
				'close'=>true,
			);

		//Пользователь не найден
		}else{
			//Возвращаем откуда пришёл
			$result=array(
				'result'=>'message',
				'message'=>'Пользователь с адресом '.$values['email'].' не найден',
				'close'=>true,
			);
		}
		//Ответ
		$this->answerInterface($values['interface'],$result);
	}

	public function updateProfile($values,$conditions=false){

		if($this->model->user->info['id']){

			foreach($values as $sid=>$value)if($sid!='interface'){
				if(!IsSet($this->interfaces['profile']['fields'][$sid]))UnSet($values[$sid]);

				if($this->structure['rec']['fields'][$sid]['type']=='image'){
					if($values[$sid]['error']>0)
						UnSet($values[$sid]);
				}
			}

			$fio = explode( ' ', trim( $values['title'] ) );
			if ( count( $fio ) < 2 ) {

				$_SESSION['errors']['title'] = 'Укажите и имя, и фамилию';
				$_SESSION['memory']['title'] = htmlspecialchars( $values['title'] );
			}

			if ( ! empty( $values['email'] ) ) {

				$email = mysql_real_escape_string( $values['email'] );
/*
				if ( $user = $this->model->execSql( "select id from users where email='$email'" ) and $user['id'] != $this->model->user->info['id'] ) {

					$_SESSION['errors']['email'] = 'Указанный адрес зарегистрирован на другого пользователя';
					$_SESSION['memory']['email'] = htmlspecialchars( $values['email'] );
					$values['email'] = '';
				}
*/
			}

			else $_SESSION['errors']['email'] = 'Укажите адрес электронной почты';

			//Доп.параметры
			$values['id']=$this->model->user->info['id'];
			$values['sid']=$this->model->user->info['login'];
			$values['date_modify']=date("Y-m-d H:i:s");

			if ( isset( $values['web'] ) )
				$values['web']=str_replace('http://','',$values['web']);
			if ( isset( $values['blog'] ) )
				$values['blog']=str_replace('http://','',$values['blog']);

			if ( isset( $values['twitter'] ) )
				$values['twitter'] = strtr( $values['twitter'], array( 'http' => '', ':' => '', '/' => '', 'twitter.com' => '' ) );
			if ( isset( $values['fb'] ) )
				$values['fb'] = strtr( $values['fb'], array( 'http' => '', ':' => '', '/' => '', 'facebook.com' => '' ) );
			if ( isset( $values['vk'] ) )
				$values['vk'] = strtr( $values['vk'], array( 'http' => '', ':' => '', '/' => '', 'vk.com' => '', 'vkontakte.ru' => '' ) );
			if ( isset( $values['lj'] ) )
				$values['lj'] = strtr( $values['lj'], array( 'http' => '', ':' => '', '/' => '', '.livejournal.com' => '' ) );

			if ( ! empty( $values['date_in'] ) )
				$values['date_in'] = date( 'Y-m-d', strtotime( $values['date_in'] ) );

			if ( ! empty( $values['date_out'] ) )
				$values['date_out'] = date( 'Y-m-d', strtotime( $values['date_out'] ) );

			$this->model->updateRecord( $this->info['sid'], 'rec', $values );

			$result=array(

				'result' => 'message',
				'message' => 'Ваш профиль обновлён',
				'close' => false
			);

			$_SESSION['interface'] = 'Ваша регистрационная анкета сохранена! Спасибо, оставайтесь на связи ;)';
		}else{

			$result=array(

				'result' => 'message',
				'message' => 'Вы не авторизованы',
				'close' => false,
			);
		}

		$this->answerInterface( $values['interface'], $result );
	}

	//Обновление профиля
	public function updateActive($values,$conditions=false){

		if($this->model->user->info['moder']){

			$rec=$this->getRecordById('rec', $values['id']);

			//Доп.параметры
			$values['id']=$values['id'];
			$values['sid']=$rec['sid'];
			$values['date_modify']=date("Y-m-d H:i:s");

			//Обновляем запись
			$this->model->updateRecord($this->info['sid'],'rec',$values);

			//Результирующий URL
			$result=array(
				'result'=>'message',
				'message'=>'Статус пользователя '.$rec['title'].' обновлён',
				'close'=>false,
			);
		}else{
			//Результирующий URL
			$result=array(
				'result'=>'message',
				'message'=>'Вы не модератор',
				'close'=>false,
			);
		}
		//Ответ
		$this->answerInterface($values['interface'],$result);
	}

	public function changePassword($values,$conditions=false){
		if($this->model->user->info['id']){

			//Здесь будем копить ошибки
			$errors=false;

			if( $values['old'] !== $values['old_copy'] )$errors['old_copy']='Введённые старые пароли не совпадают';
			if( $values['password'] !== $values['password_copy'] )$errors['password_copy']='Введённые новые пароли не совпадают';

			if( !strlen($values['password']) )$errors['password']='Вы забыли указать новый пароль';
			if( strlen($values['password']) < 6 )$errors['password']='Новый пароль должен быть длиннее 6 символов';
			if( in_array($values['password'], $this->bad_passwords) )$errors['password']='Вы ввели очень простой новый пароль, придумайте что-нибудь посложнее';
			if( $values['password'] == $this->model->user->info['login'] )$errors['password']='Пароль не может совпадать с логином';
			if( $values['password'] == $this->model->user->info['title'] )$errors['password']='Пароль не может совпадать с именем на сайте';
			if( $values['password'] == $this->model->user->info['email'] )$errors['password']='Пароль не может совпадать с адресом электронной почты';
			if( $values['password'] == $values['old'] )$errors['password']='Новый пароль не должен совпадать со старым';
			if( $this->model->types['password']->encrypt($values['old'])!=$this->model->user->info['password'])$errors['old']='Старый пароль введён неверно';

			//Выводим ошибки
			if($errors){
				//Результирующий URL
				$result=array(
					'result'=>'error',
					'errors'=>$errors,
					'close'=>false,
				);
				//Ответ
				$this->answerInterface($values['interface'],$result);
			}

			$values['id']=$this->model->user->info['id'];
			$values['sid']=$this->model->user->info['sid'];
			$values['password']=$values['password'];

			//Обновляем запись
			$this->model->updateRecord($this->info['sid'],'rec',$values);

			//Результирующий URL
			$result=array(
				'result'=>'message',
				'message'=>'Установлен новый пароль',
				'close'=>false,
			);
		}else{
			//Результирующий URL
			$result=array(
				'result'=>'message',
				'message'=>'Вы не авторизованы',
				'close'=>false,
			);
		}
		//Ответ
		$this->answerInterface($values['interface'],$result);
	}

	public function subscribe($values,$conditions=false){

		$me=$this->getRecordById('rec', $this->model->user->info['id']);
		$me=$this->explodeRecord($me);

		//Подписка
		$module_sid=$this->model->getModuleSidByPrototype( 'subscribe' );
		$sub=$this->model->modules[ $module_sid ]->getRecordById('rec', $values['subscribe']);
		$sub=$this->model->modules[ $module_sid ]->explodeRecord($sub);

		//Параметры рассылки
		$settings=array(
			'city'=>$values['city'],
			'phone'=>$values['phone'],
			'time_week'=>$values['time_week'],
			'time_weekend'=>$values['time_weekend'],
		);

		//Делаем связку
		$this->model->extensions['graph']->link(
			array (
				'top1' => $me['graph_top_text'],
				'top2' => $sub['graph_top_text'],
				'type' => 'use',
				'text' => serialize($settings),
			)
		);

		//Результирующий URL
		$result=array(
			'result'=>'redirect',
			'url'=>$this->model->user->info['url'].'.subscribe.'.$sub['sid'].'.html',
			'close'=>false,
		);

		//Ответ
		$this->answerInterface($values['interface'],$result);
	}

	private function setCookie( $name, $value ) {

		$time = time()+60*60*24*31;
		$path = '/';
		$domain = '.' . $_SERVER['HTTP_HOST'];
		setcookie( $name, $value, $time, $path, $domain );
	}

	private function deleteCookie( $name ) {
		$time = time() - 3600;
		$path = '/';
		$domain = '.' . $_SERVER['HTTP_HOST'];
		setcookie( $name, $value, $time, $path, $domain );
	}

	public function getCurrentTable() {

		return $this->table;
	}

	public function messageTo( $user_id, $message, $option = false ) {

		$user = $this->getRecordById( 'rec', $user_id );

		if($option)
			if( !$user[ $option ] )
				return false;

		$welcome = 'Привет, '.$user['title'].'.';
		$footer = '
<hr />
Желаем вам приятного дня,<br />
Администраниця сайта <a href="http://'.$this->model->extensions['domains']->domain['host'].'">'.$this->model->extensions['domains']->domain['title'].'</a>.';

		$body = '<strong>'. $welcome .'</strong><br /><br />'. $message['message'] .'<br /><br />'. $footer;

		$this->model->initEmail();
		$this->model->email->from='info@mobichel.ru';
		$this->model->email->send($user['email'],$message['subject'],$body, 'html');
	}

	public function prepareMembersWithPresentations( $params ) {

		$q = "
			select
				u.id,
				u.sid,
				p.id pid,
				p.author,
				u.company,
				u.title,
				u.city,
				u.position,
				u.url
			from
				presentation_rec p
			join
				users u
			on
				p.author = u.id
			where
				p.shw = 1
			and
				u.shw = 1
			group by
				author
			order by
				title
		";

		$r = $this->model->execSql( $q );

		foreach ( $r as &$row )
			$row = $this->insertRecordUrlType( $row );
//pr_r($r);
		return array( 'recs' => $r, 'count' => 1 );
	}

	public function prepareRegCount( $params ) {

		$q = "select count(*) cnt from users where admin!=1 and email!='' and shw=1 and id not in (select distinct author from presentation_rec)";
		$r = $this->model->execSql( $q, 'getrow' );
		return intval( $params['max'] ) - $r['cnt'];
	}

	public function prepareDel( $params ) {

		$id = $this->model->user->info['id'];
		if ( $id )
			$this->model->execSql( "delete from users where id=$id", 'delete' );
		header( 'Location:/?logout=1' );
		exit();
	}

	public function prepareSearch( $params ) {

		$str = mysql_real_escape_string( strip_tags( $params['q'] ) );
		$r['recs'] =
			$this->model->execSql(
				"select * from
					users
				where (
					title like '%$str%'
				or
					email like '%$str%'
				or
					openid like '%$str%'
				or
					company like '%$str%'
				or
					city like '%$str%'
				or
					position like '%$str%'
				)
				and shw=1 and email!=''
			" );

		foreach ( $r['recs'] as &$val )
			$val = $this->insertRecordUrlType( $val );

		return $r;
	}
}

?>
