<?php

class start_module extends default_module{

	public $title='Статьи';

	public $items_per_page = 10;

	//Шаблоны в модуле по умолчанию
	public $prepares=array(
		'myvote' => array( 'function' => 'prepareMyVote', 'title' => '' ),
		'mylike' => array( 'function' => 'prepareMyLike', 'title' => '' ),
		'footer' => array( 'function' => 'prepareFooter', 'title' => 'Меню внизу страницы' ),
		'twits' => array( 'function' => 'prepareTwits', 'title' => 'Получить твиты' ),
		'pro' => array( 'function' => 'prepareProtect', 'title' => '' ),
	);

	public function setStructure() {

		$this->structure=array(
			'rec'=>array(
				'title'=>$this->title,
				'fields'=>array(
					'preview'=>			array('type'=>'textarea','group'=>'main','title'=>'Краткий текст'),
					'text'=>			array('type'=>'text_editor','group'=>'main','title'=>'Текст'),
					'img'=>				array('type'=>'image','group'=>'media','title'=>'Заглавная картинка','resize_type'=>'inner','resize_width'=>'1920','resize_height'=>'1920','pre'=>array(
						'slide'=>			array('sid'=>'slide', 'resize_type'=>'width', 'resize_width'=>800),
						'big'=>				array('sid'=>'big','resize_type'=>'width','resize_width'=>'350','resize_height'=>'600'),
						'anons'=>			array('sid'=>'anons','resize_type'=>'inner','resize_width'=>'165','resize_height'=>'165'),
						'list'=>			array('sid'=>'list','resize_type'=>'inner','resize_width'=>'125','resize_height'=>'125'),
						'tiny'=>			array('sid'=>'tiny','resize_type'=>'inner','resize_width'=>'63','resize_height'=>'63')
					)),
					'gallery'=>			array('type'=>'gallery','group'=>'media','title'=>'Фотографии','resize_type'=>'inner','resize_width'=>'1200','resize_height'=>'1200','pre'=>array(
							'pre'=>			array('sid'=>'pre','resize_type'=>'outer','resize_width'=>'94','resize_height'=>'94'),
					)),
					'video' => array( 'type' => 'html', 'group' => 'media', 'title' => 'Видео-ролик или презентация' ),
					'feedback'=>		array('type'=>'feedback','group'=>'feedback','title'=>'Форма обратной связи'),
					'show_in_anons'=>	array('type'=>'check','group'=>'show','title'=>'Раздел не активен','default'=>false),
					'show_in_menu'=>	array('type'=>'check','group'=>'show','title'=>'Показывать в главном меню','default'=>false),
					'show_in_footer'=>	array('type'=>'check','group'=>'show','title'=>'Показывать в подвале','default'=>false),

					'ads'=>				array('type'=>'check','group'=>'additional','title'=>'Рекламный материал'),
					'ads_color'=>		array('type'=>'text','group'=>'additional','title'=>'Рекламный материал - цвет','default'=>'#f9c'),

					'comments' => array('type'=>'comments','group'=>'additional','title'=>'Разрешить комментарии','default'=>false),
					'votes' => array('type'=>'votes','group'=>'additional','title'=>'Голосование за запись','default'=>false),
					'tags' => array('type'=>'tags','group'=>'additional','title'=>'Теги','default'=>false),
					'template' => array( 'type' => 'menu', 'group' => 'system', 'title' => 'Шаблон', 'variants' => $templates ),
					'goto' => array( 'type' => 'link', 'group' => 'system', 'title' => 'Запись является ссылкой на раздел', 'module' => '0', 'structure_sid' => 'rec' )
				),
				'type'=>'tree',
				'dep_path'=>false,
				'dep_param'=>false,
			),
		);
	}

	//Установка интерфейсов модуля
	public function setInterfaces(){

		$this->interfaces=array(
			'graph_start'=>array(
				'title'=>'Начало связи графа',		//Название интерфейса
				'structure_sid'=>'rec',					//Используемая структура текущего модуля
				'fields'=>array(
					'top1'=>array('sid'=>'top1','type'=>'text'),
					'type'=>array('sid'=>'type','type'=>'text'),
				),										//Поля, доступные в интерфейсе
				'ajax'=>true,
				'protection'=>false,					//Защита формы
				'auth'=>true,							//Требуется ли авторизация для работы с интерфейсом
				'use_record'=>false,						//Использовать ли уже имеющуюся запись
				'control'=>'graphLink_start',					//Функция, отвечающая за обработку интерфейса после отправки
			),
			'graph_finish'=>array(
				'title'=>'Окончание связи графа',		//Название интерфейса
				'structure_sid'=>'rec',					//Используемая структура текущего модуля
				'fields'=>array(
					'id'=>array('sid'=>'id','type'=>'text'),
					'top2'=>array('sid'=>'top2','type'=>'text'),
					'type'=>array('sid'=>'type','type'=>'text'),
				),										//Поля, доступные в интерфейсе
				'ajax'=>true,
				'protection'=>false,					//Защита формы
				'auth'=>true,							//Требуется ли авторизация для работы с интерфейсом
				'use_record'=>false,						//Использовать ли уже имеющуюся запись
				'control'=>'graphLink_finish',					//Функция, отвечающая за обработку интерфейса после отправки
			),
			'graph_link'=>array(
				'title'=>'Связь',		//Название интерфейса
				'structure_sid'=>'rec',					//Используемая структура текущего модуля
				'fields'=>array(
					'id'=>array('sid'=>'id','type'=>'text'),
					'top1'=>array('sid'=>'top1','type'=>'text'),
					'top2'=>array('sid'=>'top2','type'=>'text'),
					'type'=>array('sid'=>'type','type'=>'text'),
				),										//Поля, доступные в интерфейсе
				'ajax'=>true,
				'protection'=>false,					//Защита формы
				'auth'=>true,							//Требуется ли авторизация для работы с интерфейсом
				'use_record'=>false,						//Использовать ли уже имеющуюся запись
				'control'=>'graphLink_link',					//Функция, отвечающая за обработку интерфейса после отправки
			),
			'graph_unlink'=>array(
				'title'=>'Убрать Связь',		//Название интерфейса
				'structure_sid'=>'rec',					//Используемая структура текущего модуля
				'fields'=>array(
					'id'=>array('sid'=>'id','type'=>'text'),
					'top1'=>array('sid'=>'top1','type'=>'text'),
					'top2'=>array('sid'=>'top2','type'=>'text'),
					'type'=>array('sid'=>'type','type'=>'text'),
				),										//Поля, доступные в интерфейсе
				'ajax'=>true,
				'protection'=>false,					//Защита формы
				'auth'=>true,							//Требуется ли авторизация для работы с интерфейсом
				'use_record'=>false,						//Использовать ли уже имеющуюся запись
				'control'=>'graphLink_unlink',					//Функция, отвечающая за обработку интерфейса после отправки
			),
		);

		$this->interfaces['like_unlink'] =
		$this->interfaces['vote_unlink'] = array(

			'title' => 'Unrate',
			'structure_sid' => 'rec',
			'fields' => array(
				'id' => array( 'sid' => 'id', 'type' => 'id' ),
				'top' => array( 'sid' => 'top', 'type' => 'text' ),
			),
			'ajax' => true,
			'protection' => false,
			'auth' => true,
			'use_record' => true,
			'control' => 'unlinkVote',
		);
		
		$this->interfaces['like'] = array(

			'title' => 'Like',
			'structure_sid' => 'rec',
			'fields' => array(
				'id' => array( 'sid' => 'id', 'type' => 'id' ),
				'top' => array( 'sid' => 'top', 'type' => 'text' ),
			),
			'ajax' => true,
			'protection' => false,
			'auth' => true,
			'use_record' => true,
			'control' => 'like',
		);
	}

	//Личное меню пользователя
	public function prepareFooter($params){

		//Получаем условия
		$where=$this->convertParamsToWhere($params);

		//Условия отображения на сайте
		$where['and'][]='`show_in_footer`=1';
		$where['and']['dep_path_parent']='`dep_path_parent`="index"';

		//Сортировка
		$order=$this->getOrderBy('rec');

		//Забираем записи
		$recs=$this->model->makeSql(
			array(
				'tables'=>array($this->getCurrentTable('rec')),
				'where'=>$where,
				'order'=>$order,
			),
			'getall'
		);

		//Раскрываем сложные поля
		if($recs)
		foreach($recs as $i=>$rec){

			$rec=$this->explodeRecord($rec,'rec');
			$rec=$this->insertRecordUrlType($rec);

			//Подразделы
			$where['and']['dep_path_parent']='`dep_path_parent`="'.$rec['sid'].'"';
			$subs = $this->model->makeSql(
				array(
					'tables'=>array($this->getCurrentTable('rec')),
					'where'=>$where,
					'order'=>$order,
				),
				'getall'
			);

			if ($subs){
				foreach($subs as $j=>$sub){
					$sub=$this->explodeRecord($sub,'rec');
					$sub=$this->insertRecordUrlType($sub);
					$subs[$j]=$sub;
				}
				$rec['sub'] = $subs;
			}

			$recs[$i]=$rec;
		}

		//Готово
		return $recs;
	}

 	//Дополнительная обработка записи при типе вывода "content"
	public function contentPrepare($rec,$structure_sid='rec'){

		//Twitter
		if($rec['sid'] == 'twitter'){
			$rec['twits'] = $this->prepareTwits(array('limit'=>20));
		}

		return $rec;
	}

	public function prepareMyVote($values){
		list($module, $structure_sid, $record_id) = explode('|', $values['top']);
		$rec = $this->model->execSql('select * from `votes` where `module`="'.$module.'" and `structure_sid` = "'.$structure_sid.'" and `record_id`="'.$record_id.'" and `author`="'.$this->model->user->info['id'].'" limit 1', 'getrow');
		return $rec;
	}

	public function prepareMyLike($params){

		$module = $params['mod'];
		$part = $params['part']; 
		$record_id = $params['id'];

		$rec = $this->model->execSql('select * from `likes` where `module`="'.$module.'" and `structure_sid` = "'.$part.'" and `record_id`="'.$record_id.'" and `author`="'.$this->model->user->info['id'].'" limit 1', 'getrow');
		return $rec;
	}

	public function like( $params ) {
	
		list( $module, $part, $id ) = explode( '|', $params['top'] );

		$author = $this->model->user->info['id'];

		$id = (int) $id;
		$part = preg_replace( "/[^a-z]/", '', $part );
		$module = preg_replace( "/[^a-z]/", '', $module );

		if ( ! $r = $this->model->execSql( "select id from likes where record_id=$id and module='$module' and structure_sid='$part' and author=$author" ) ) {
			
			$this->model->execSql( $q = "insert into likes set date=now(),ln=1,domain='all',record_id=$id, module='$module', structure_sid='$part', author=$author", 'insert' );
			$this->model->execSql( $q = "update {$module}_{$part} set likes=likes+1 where id=$id", 'update' );
		}
		
		exit();
	}

	public function unlinkVote( $params, $conditions = false ) {

		$author = $this->model->user->info['id'];
		$table = $field = $params['interface'] == 'vote_unlink' ? 'votes' : 'likes'; 

		if ( ! $author or empty( $params['top'] ) )
			$this->answerInterface( $params['interface'], array( 'message' => 'fail' ) );

		list( $module, $part, $id ) = explode( '|', $params['top'] );

		$id = (int) $id;
		$part = preg_replace( "/[^a-z]/", '', $part );
		$module = preg_replace( "/[^a-z]/", '', $module );

		$this->model->execSql( $q = "delete from $table where author=$author and record_id=$id and module='$module' and structure_sid='$part'", 'delete' );

		if ( $table == 'votes' and $r = $this->model->execSql( "select $field votes from {$module}_{$part} where id=$id", 'getrow' ) ) {

			$ex = explode( '|', $r['votes'] );
			if ( sizeof( $ex ) == 4 ) {
				-- $ex[0];
				-- $ex[2];
			}

			$votes = implode( '|', $ex );
			$this->model->execSql( "update {$module}_{$part} set votes='$votes' where id=$id", 'update' );
		}
		
		else {
			
			$this->model->execSql( $q = "update {$module}_{$part} set likes=(select count(id) from $table where module='$module' and structure_sid='$part' and record_id=$id) where id=$id", 'update' );
		}

		$this->answerInterface( $params['interface'], array( 'message' => 'ok' ) );
	}

	//Показать твиты
	public function prepareTwits($params){

		$recs = $this->model->execSql('select * from `twitter_rec` order by `date_public` desc limit '.intval($params['limit']).'','getall');
		foreach($recs as $i=>$rec)
			$recs[$i]['date_public'] = $this->model->types['datetime']->getValueExplode($rec['date_public']);

		return $recs;
	}

	public function prepareProtect( $params ) {

		global $white_ips;
		return in_array( GetUserIP(), $white_ips );
	}
}

?>
