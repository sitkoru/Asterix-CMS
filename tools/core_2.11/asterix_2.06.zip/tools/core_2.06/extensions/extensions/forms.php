<?php

/************************************************************/
/*															*/
/*	Ядро системы управления Asterix	CMS						*/
/*		Расширение форм обратной связи						*/
/*															*/
/*	Версия ядра 2.0.b5										*/
/*	Версия скрипта 1.00										*/
/*															*/
/*	Copyright (c) 2009  Мишин Олег							*/
/*	Разработчик: Мишин Олег									*/
/*	Email: dekmabot@gmail.com								*/
/*	WWW: http://mishinoleg.ru								*/
/*	Создан: 10 февраля 2009	года							*/
/*	Модифицирован: 25 сентября 2009 года					*/
/*															*/
/************************************************************/

require_once 'default.php';

class extention_forms extends extention_default
{
	var $title = 'Формы';
	var $sid = 'ext_forms';
	var $table_name = 'ext_forms';
	
	//Инициализация расширения
	public function __construct($db, $log)
	{
		$this->log = $log;
	}
	
	//Запуск модуля
	public function onModuleStart()
	{
	}
	
	//Запуск контроллера
	public function onControllerStart()
	{
	}
	
	//Подготовка записи
	public function onRecordPrepare()
	{
	}
	
	//Добавляем системное поле в модуль
	public function addFields()
	{
		return array(
			$this->sid => array(
				'sid' => $this->sid,
				'group' => 'additional',
				'type' => 'check',
				'title' => $this->title,
				'value' => 'all'
			)
		);
	}
	
	//Перед записью данных в шаблонизатор
	public function onAssign()
	{
	}
	
	//Перед обработкой шаблона
	public function onFetch()
	{
	}
}

?>