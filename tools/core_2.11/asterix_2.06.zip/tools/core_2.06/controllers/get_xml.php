<?php

/************************************************************/
/*															*/
/*	Ядро системы управления Asterix	CMS						*/
/*		Контроллер GET-запросов	с выводом данных в виде XML	*/
/*															*/
/*	Версия ядра 2.0											*/
/*	Версия скрипта 1.00										*/
/*															*/
/*	Copyright (c) 2009  Мишин Олег							*/
/*	Разработчик: Мишин Олег									*/
/*	Email: dekmabot@gmail.com								*/
/*	WWW: http://mishinoleg.ru								*/
/*	Создан: 3 ноября 2009 года								*/
/*	Модифицирован: 3 ноября 2009 года						*/
/*															*/
/************************************************************/

require('default_controller.php');

class controller_get_xml extends default_controller
{
	public function start()
	{
		//Подготавливаем запись
		$main_record = $this->model->prepareMainRecord();
		
		//Задаём кодировку ответа
		header('Content-Type: text/html; charset=utf-8');
		
		//Подключаем библиотеку
		require_once($this->model->config['path']['libraries'] . '/array2xml.php');
		
		
		//Создаём объект конвертора
		$array2xml = new Array2XML();
		//Конвертируем
		$res       = $array2xml->convert($main_record);
		//Выводим
		print($res);
		//Стоп
		exit();
		
		//Учёт посещений поисковиков
		$this->model->extensions['seo']->crawlerCount();
	}
}
?>