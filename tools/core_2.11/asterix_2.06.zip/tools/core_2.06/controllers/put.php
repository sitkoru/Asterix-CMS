<?php

require('default_controller.php');

class controller_put extends default_controller
{
	//Читаем переменные, переданные с нестандартным методом.
	function loadData()
	{
		/*	
		//Разбираем переменные
		if(strlen($_SERVER['argv'][0])>3){
		$t=explode('&',$_SERVER['argv'][0]);
		foreach($t as $ti){
		$i=explode('=',$ti);
		$this->vars[$i[0]]=urldecode($i[1]);
		}
		}
		*/
		$this->vars = $_POST;
		if (IsSet($_FILES))
			$this->vars = array_merge($this->vars, $_FILES);
		
		//Подключаем менеджер действий, инициализируем класс действия
		require($this->model->config['path']['actions'] . '/action_manager.php');
		$this->actionManager = new actionManager($this->vars['action'], $this->model);
	}
	
	//Основная цункция контроллера, получающая управление после инициализации
	public function start($vars)
	{
		if (!$this->model->user->info['admin']) {
			pr('У вас нет доступа на это действие.');
			exit();
		}
		
		if (!IsSet($this->vars['module'])) {
			$this->actionManager->current_action->controlInput($this->vars);
			header('Location: ' . $this->model->ask->original_url);
			exit();
		}
		
		//Определяемся куда указывает URL
		if ($vars['action'] != 'settings')
			$main_record = $this->model->prepareMainRecord();
		
		//Действие по умолчанию
		$this->model->addRecord($this->vars['module'], $this->vars['structure_sid'], $this->vars);
	}
}

?>