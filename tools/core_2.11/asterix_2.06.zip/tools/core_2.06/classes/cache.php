<?php

/************************************************************/
/*															*/
/*	Ядро системы управления Asterix	CMS						*/
/*		Класс работы с кешем контроллеров					*/
/*															*/
/*	Версия ядра 2.0.b5										*/
/*	Версия скрипта 0.01										*/
/*															*/
/*	Copyright (c) 2009  Мишин Олег							*/
/*	Разработчик: Мишин Олег									*/
/*	Email: dekmabot@gmail.com								*/
/*	WWW: http://mishinoleg.ru								*/
/*	Создан: 10 февраля 2009	года							*/
/*	Модифицирован: 25 сентября 2009 года					*/
/*															*/
/************************************************************/

class cache
{
	//Конструктор
	public function __construct($config, $log)
	{
		$this->config = $config;
		$this->log    = $log;
	}
	
	//Создание файла кеша
	public function makeCache($html)
	{
		//Если пользователь не авторизован
		
		if ($this->config['cache'])
//			if (!IsSet($_SESSION['messages']))
//				if (!IsSet($_SESSION['form_captcha_code']))
//					if (!IsSet($_COOKIE['auth']))
					{
						//Путь кеш-файла
						$path = $this->config['path']['cache'] . '/' . $_SERVER['HTTP_HOST'] . '_' . md5($_SERVER['REQUEST_URI']);
						//Сохраняем кеш
						file_put_contents($path, $html);
					}
	}
	
	//Чтение файла кеша
	public function readCache()
	{
		if ($this->config['cache'])
//			if ($_SERVER['REQUEST_METHOD'] == 'GET')
//				if (!IsSet($_SESSION['messages']))
//					if (!IsSet($_SESSION['disable_cache']))
//						if (!IsSet($_COOKIE['auth']))
						{
							//Путь кеш-файла
							$path = $this->config['path']['cache'] . '/' . $_SERVER['HTTP_HOST'] . '_' . md5($_SERVER['REQUEST_URI']);
							
							//Если файл существует
							if (file_exists($path)) {
								//Выдаём кеш
								readfile($path);
								//Показать статистику
								$this->log->showStat();
								//Готово
								exit();
							}
						}
	}
	
	//Обновление файлов кеша
	public function clearCache($hosts)
	{
		if ($this->config['cache']) {
			//Готовим команды
			$commands = array();
			foreach ($hosts as $host) {
				$commands[] = 'rm ' . $this->config['path']['cache'] . '/' . $host . '_*';
				$commands[] = 'rm ' . $this->config['path']['cache'] . '/www.' . $host . '_*';
			}
			
			//Выполняем команды
			if (!strstr(ini_get('suhosin.executor.funct.blacklist'), 'exec'))
				foreach ($commands as $command)
					exec($command);
		}
	}
}

?>
